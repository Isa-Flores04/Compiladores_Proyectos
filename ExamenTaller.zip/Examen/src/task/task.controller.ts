import { Controller } from '@nestjs/common';

@Controller('Examen/compilador/unidad1')
export class TaskController {}
